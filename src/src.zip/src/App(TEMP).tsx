import React from 'react'

const App(TEMP) = () => {
  return (
    <div>App(TEMP)</div>
  )
}

export default App(TEMP)