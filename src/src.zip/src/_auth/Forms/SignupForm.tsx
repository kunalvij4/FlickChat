
import { Button } from "@/components/ui/button"
const SignupForm = () => {
  return (
    <div>
      <Button>Click me</Button>
    </div>
  )
}

export default SignupForm