import React from 'react'

const RootLayout = () => {
  return (
    <div>RootLayout</div>
  )
}

export default RootLayout